/*
 Created by roberto on 30/4/21.
*/

#ifndef NCOURSES_MENU_H
#define NCOURSES_MENU_H
/* Menu related stuff */
/*
#define MAINMENUHEIGHT 3
#define NOMAINMENUITEMS 3
*/
#include <stdlib.h>
#include "loop.h"
/* forms related stuff
#define FORMITEMS1 2
#define FORMWIDTH 30*/
/* funcions */

#endif /* NCOURSES_MENU_H */
